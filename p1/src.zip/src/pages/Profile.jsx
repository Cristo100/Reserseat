export default function Profile() {
    // Futuro: obtener reservas del usuario
    return (
      <section className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow">
        <h1 className="text-xl font-semibold mb-4">Mi Perfil</h1>
        <p>Aquí verás tus reservas activas y un historial.</p>
      </section>
    )
  }