export default function Login() {
    return (
      <section className="max-w-sm mx-auto bg-white p-6 rounded-lg shadow">
        <h1 className="text-xl font-semibold mb-4 text-center">Iniciar sesión</h1>
        <form className="grid gap-4">
          <input className="input" placeholder="Correo corporativo" />
          <input className="input" type="password" placeholder="Contraseña" />
          <button type="submit" className="btn-primary">Entrar</button>
        </form>
      </section>
    )
  }