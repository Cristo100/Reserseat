import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <section className="text-center space-y-6">
      <h1 className="text-2xl font-bold">Bienvenido al Comedor Empresarial</h1>
      <div className="flex justify-center gap-4 flex-wrap">
        <Link to="/reservation" className="btn-primary">Reservar asiento</Link>
        <Link to="/menu" className="btn-secondary">Ver menú</Link>
      </div>
    </section>
  )
}