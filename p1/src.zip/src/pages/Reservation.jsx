import { useState } from 'react'

export default function Reservation() {
  const [form, setForm] = useState({ nombre: '', telefono: '', hora: '13:00', personas: 1 })

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((f) => ({ ...f, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    alert(`Reserva creada para ${form.nombre}`)
  }

  return (
    <section className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow">
      <h1 className="text-xl font-semibold mb-6">Nueva reservación</h1>
      <form onSubmit={handleSubmit} className="grid gap-4">
        <input className="input" name="nombre" placeholder="Nombre" value={form.nombre} onChange={handleChange} required />
        <input className="input" name="telefono" placeholder="Teléfono" value={form.telefono} onChange={handleChange} required />
        <label className="block">
          Hora:<br />
          <input type="time" name="hora" value={form.hora} onChange={handleChange} className="input mt-1" />
        </label>
        <label className="block">
          Personas (máx 5):<br />
          <input type="number" name="personas" min="1" max="5" value={form.personas} onChange={handleChange} className="input mt-1" />
        </label>
        <button type="submit" className="btn-primary w-full">Confirmar</button>
      </form>
    </section>
  )
}