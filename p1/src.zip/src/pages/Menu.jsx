const FAKE_MENU = [
    { id: 1, plato: 'Pollo grillé con verduras', precio: '$7.900' },
    { id: 2, plato: 'Ensalada César', precio: '$5.500' },
    { id: 3, plato: 'Pastel de choclo', precio: '$6.800' },
  ]
  
  export default function Menu() {
    return (
      <section className="max-w-md mx-auto bg-white p-6 rounded-lg shadow">
        <h1 className="text-xl font-semibold mb-4">Menú de hoy</h1>
        <ul className="space-y-2">
          {FAKE_MENU.map((item) => (
            <li key={item.id} className="flex justify-between border-b pb-1">
              <span>{item.plato}</span>
              <span className="font-medium">{item.precio}</span>
            </li>
          ))}
        </ul>
      </section>
    )
  }