import { NavLink } from 'react-router-dom'

const navClass = ({ isActive }) =>
  `px-3 py-2 rounded-md text-sm font-medium ${isActive ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-blue-100'}`

export default function Navbar() {
  return (
    <header className="bg-white shadow">
      <nav className="container mx-auto flex gap-2 p-4 justify-center md:justify-start">
        <NavLink to="/home" className={navClass}>Inicio</NavLink>
        <NavLink to="/reservation" className={navClass}>Reservación</NavLink>
        <NavLink to="/menu" className={navClass}>Menú</NavLink>
        <NavLink to="/profile" className={navClass}>Perfil</NavLink>
      </nav>
    </header>
  )
}