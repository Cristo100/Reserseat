// src/components/ReservationForm.jsx
import { useState } from 'react'

export default function ReservationForm({ selectedTable, onReserve }) {
  const [name, setName] = useState('')
  const [people, setPeople] = useState(1)
  const [time, setTime] = useState('13:00')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!selectedTable) return alert('Selecciona una mesa primero')
    onReserve({ table: selectedTable.name, name, people, time })
    setName('')
  }

  return (
    <form onSubmit={handleSubmit} className="reservation-form">
      <h2>Nueva reserva</h2>

      <label>
        Nombre&nbsp;
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </label>

      <label>
        Personas&nbsp;
        <input
          type="number"
          min="1"
          max={selectedTable?.seats || 10}
          value={people}
          onChange={(e) => setPeople(e.target.value)}
        />
      </label>

      <label>
        Hora&nbsp;
        <input
          type="time"
          value={time}
          onChange={(e) => setTime(e.target.value)}
        />
      </label>

      <button type="submit">Reservar</button>
    </form>
  )
}
